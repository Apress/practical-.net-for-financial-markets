using System;
using System.IO;
using WallStreet.DCE.Repository;
using WallStreet.DCE.Collectors;

namespace WallStreet.DCE.Translators
{
	/// <summary>
	/// Summary description for IWriter.
	/// </summary>
	public interface IWriter
	{
		void WriteStartColumn(MetaData metaDataInfo, Parser parser);
		void WriteEndColumn(MetaData metaDataInfo);
		void WriteStartRow(MetaData metaDataInfo,Parser parser);
		void WriteEndRow(MetaData metaDataInfo);
		void WriteStartBand(MetaData metaDataInfo,Parser parser);
		void WriteEndBand(MetaData metaDataInfo);
		TextWriter BaseWriter
		{get;}

	}
}
