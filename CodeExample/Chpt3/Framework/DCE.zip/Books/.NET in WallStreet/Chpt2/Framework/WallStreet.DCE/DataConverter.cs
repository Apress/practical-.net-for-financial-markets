using System;
using System.IO;
using System.Xml.Serialization;
using WallStreet.DCE.Repository;
using WallStreet.DCE.Collectors;
using WallStreet.DCE.Translators;
using System.Xml;
using System.Xml.Schema;
using System.Configuration;

namespace WallStreet.DCE
{
	public class DataConverter
	{
		private DCESchema _dceSchema;
		private IWriter _dataWriter;
		private RowParser _rowParser;
		private ColumnParser _colParser;
		private IReader _dataReader;

		public DataConverter(string dceSchemaFile,IReader dataReader, IWriter dataWriter)
		{
			AppSettingsReader configReader;

			configReader = new AppSettingsReader();
			XmlTextReader xmlSchema = new XmlTextReader(dceSchemaFile);
			XmlValidatingReader xsdSchema = new XmlValidatingReader(xmlSchema);
			XmlSchemaCollection schemaCol = new XmlSchemaCollection();
			
			try
			{
				schemaCol.Add("",(string)configReader.GetValue("SchemaFile",typeof(string)));
				xsdSchema.Schemas.Add(schemaCol);
				while(xsdSchema .Read()){}
			}
			catch(Exception)
			{
				throw;
			}
			finally
			{
				xsdSchema .Close();
				xmlSchema.Close();
			}			
			
			FileStream schemaStream = new FileStream(dceSchemaFile, FileMode.Open);
			XmlSerializer schemaSz = new XmlSerializer(typeof(DCESchema));
			_dceSchema = (DCESchema)schemaSz.Deserialize(schemaStream );


			schemaStream.Close();
			
			_dceSchema.Initialize();
			_dataWriter= dataWriter;
			_dataReader = dataReader;
			_rowParser = new RowParser(_dataReader);
			_colParser = new ColumnParser(_dataReader);

		}

		public void Convert()
		{
			foreach ( Band curBand in _dceSchema.Bands ) 
			{
				ConvertBand(curBand,_dataReader.Next());
			}

			_dataReader.BaseReader.Close();
			_dataWriter.BaseWriter.Close();
		}


		private void ConvertBand(Band band,string data)
		{
			BandParser bandParser;

			//Assign the New Band Parser and Data
			bandParser = new BandParser(_dataReader);
			bandParser.Data = data;
			bandParser.MetaData = band;
			_dataWriter.WriteStartBand(band,bandParser);
			while ( bandParser.Parse()== true ) 
			{
				foreach ( Row row in band.Rows)
				{
					_rowParser = new RowParser(_dataReader);
					_rowParser.Data = data;
					_rowParser.MetaData =row;
					
					if ( row.Band != null ) 
					{
						ConvertBand	(row.Band,data);
					}
					else
					{
						ConvertRow(row,data);
					}
					
					data = _dataReader.Next();
				}
				bandParser.Data = data;
			}
			_dataWriter.WriteEndBand(band);
		}

		private void ConvertRow(Row row,string data)
		{

			_dataWriter.WriteStartRow(row,_rowParser);
			if ( _rowParser.Parse() == false ) 
			{
				_dataWriter.WriteEndRow(row);
				return ;
			}

			foreach ( Column col in row.Columns)
			{
				ConvertCol(row,col,data);
			}
			_dataWriter.WriteEndRow(row);

		}

		private void ConvertCol(Row row,Column col,string data)
		{
			_colParser.MetaData = col;
			_colParser.Data = data;
			_colParser.Parse();
			_dataWriter.WriteStartColumn(col,_colParser);
			_dataWriter.WriteEndColumn(col);;			
		}

	}
}
