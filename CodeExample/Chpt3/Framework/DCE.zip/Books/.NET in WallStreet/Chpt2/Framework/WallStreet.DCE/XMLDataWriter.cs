using System;
using System.Xml;
using System.IO;
using WallStreet.DCE.Repository;
using WallStreet.DCE.Collectors;


namespace WallStreet.DCE.Translators
{
	public class XMLDataWriter: IWriter
	{
		private XmlTextWriter _xmlWriter;
		private TextWriter _baseWriter;

		public XMLDataWriter(TextWriter dataWriter)
		{
			_xmlWriter = new XmlTextWriter(dataWriter);
			_xmlWriter.Formatting=  Formatting.Indented;
			_xmlWriter.Indentation = 4;
			_baseWriter = dataWriter;
		}

		public void WriteStartColumn(MetaData metaDataInfo, Parser parser)
		{
			_xmlWriter.WriteStartAttribute(metaDataInfo.Name,"");
			_xmlWriter.WriteString(parser.Data);				

		}

		public void WriteEndColumn(MetaData metaDataInfo)
		{
			_xmlWriter.WriteEndAttribute();
		}

		public void WriteStartRow(MetaData metaDataInfo, Parser parser)
		{
			_xmlWriter.WriteStartElement(metaDataInfo.Name);
		}

		public void WriteEndRow(MetaData metaDataInfo)
		{
			_xmlWriter.WriteEndElement();
		}

		public void WriteStartBand(MetaData metaDataInfo, Parser parser)
		{
			_xmlWriter.WriteStartElement(metaDataInfo.Name);
		}

		public void WriteEndBand(MetaData metaDataInfo)
		{
			_xmlWriter.WriteEndElement();
		}

		public TextWriter BaseWriter
		{
			get{return _baseWriter;}
		}

	}
}
