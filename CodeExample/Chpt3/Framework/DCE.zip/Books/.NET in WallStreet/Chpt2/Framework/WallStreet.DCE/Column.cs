using System;
using System.Xml.Serialization;

namespace WallStreet.DCE.Repository
{
	/// <summary>
	/// Summary description for Column.
	/// </summary>
	public class Column : MetaData
	{
		private string _txtPrefix;
		
		public Column()
		{
		}

		[XmlAttribute("prefix")]
		public string Prefix
		{
			get{return _txtPrefix;}
			set{_txtPrefix = value;}
		}


	}
}
