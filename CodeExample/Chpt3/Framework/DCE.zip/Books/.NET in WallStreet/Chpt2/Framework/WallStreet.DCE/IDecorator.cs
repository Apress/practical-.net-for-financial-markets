using System;

namespace WallStreet.DCE
{
	/// <summary>
	/// Summary description for IDecorator.
	/// </summary>
	public interface IDecorator
	{
		void DecorateStartColumn(MetaDataInfo metaDataInfo, Parser parser);
		void DecorateEndColumn(MetaDataInfo metaDataInfo);
		void DecorateStartRow(MetaDataInfo metaDataInfo,Parser parser);
		void DecorateEndRow(MetaDataInfo metaDataInfo);
		void DecorateStartBand(MetaDataInfo metaDataInfo,Parser parser);
		void DecorateEndBand(MetaDataInfo metaDataInfo);
	}
}
