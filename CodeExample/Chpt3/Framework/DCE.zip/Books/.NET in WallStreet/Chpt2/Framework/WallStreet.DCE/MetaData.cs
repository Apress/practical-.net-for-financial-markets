using System;
using System.Xml.Serialization;

namespace WallStreet.DCE.Repository
{
	/// <summary>
	/// Summary description for MetaData.
	/// </summary>
	public abstract class MetaData
	{
		private string _txtIdentifier;
		private int _txtStart;
		private string _Name;
		private int _index;
		private int _childCount;
		private int _txtLength;
		private MetaData _parentMetaData;

		[XmlIgnore]
		public MetaData ParentMetaData
		{
			get{return _parentMetaData;}
			set{_parentMetaData= value;}
		}

		[XmlIgnore]
		public int TotalChild
		{
			get{return _childCount;}
			set{_childCount =value;}
		}

		[XmlIgnore]
		public int Index
		{
			get{return _index;}
			set{_index=value;}
		}

		[XmlAttribute("name")]
		public string Name
		{
			get{return _Name;}
			set{_Name = value;}
		}

		[XmlAttribute("identifier")]
		public string Identifier
		{
			get{return _txtIdentifier;}
			set{_txtIdentifier=value;}
		}

		[XmlAttribute("start")]
		public int Start
		{
			get{return _txtStart;}
			set{_txtStart = value;}
		}

		[XmlAttribute("length")]
		public int Length
		{
			get{return _txtLength;}
			set{_txtLength = value;}
		}

	}
}
