using System;
using WallStreet.DCE.Translators;

namespace WallStreet.DCE.Collectors
{
	/// <summary>
	/// Summary description for RowParser.
	/// </summary>
	public class RowParser : Parser
	{

		public RowParser(IReader dataReader) 
			:base(dataReader)
		{
		}
 
		public override bool Parse()
		{
			
			//Check for the particular identifier
			//if it exist then iterate thru the columns
			if ( MetaData.Identifier.Length > 0 && Data.Substring(MetaData.Start,MetaData.Length) != MetaData.Identifier )
			{
				//Check if the row exist but identifier doesn't exist then move back the pointer
				Reader.Previous();
				return false;
			}
			
			//Converter.DecorateStartRow(this.CurrentRow,this);
			return true;
		}
	}
}
