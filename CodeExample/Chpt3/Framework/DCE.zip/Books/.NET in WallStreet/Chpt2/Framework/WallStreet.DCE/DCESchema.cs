using System;
using System.Xml.Serialization;

namespace WallStreet.DCE.Repository
{
	/// <summary>
	/// Summary description for MetaData.
	/// </summary>
	[XmlRoot("dce")]	
	public class DCESchema
	{
		private Band[] _bands;
		public DCESchema()
		{
		}

		[XmlArray("bands")]
		[XmlArrayItem("band",typeof(Band))]
		public Band[] Bands
		{
			get{return _bands;}
			set{_bands = value;}
		}

		internal void Initialize()
		{
			foreach ( Band curBand in Bands)
			{
				AssignRowIndex(curBand);
			}
		}

		private void AssignRowIndex(Band curBand)
		{
			int rowMetaIndex;
			int colMetaIndex;

			rowMetaIndex=1;
			foreach(Row curRow in curBand.Rows)
			{
				curRow.Index = rowMetaIndex;
				curRow.ParentMetaData= curBand;
				if ( curRow.Band != null ) 
				{
					AssignRowIndex(curRow.Band);
				}
				else
				{
					colMetaIndex=1;
					foreach(Column curCol in curRow.Columns)
					{
						curCol.Index = colMetaIndex;
						curCol.ParentMetaData= curRow;
						colMetaIndex++;
					}
					curRow.TotalChild = --colMetaIndex;
				}
				rowMetaIndex++;
			}
			curBand.TotalChild = --rowMetaIndex;
		}
	}
}
