using System;
using System.Xml.Serialization;

namespace WallStreet.DCE.Repository
{
	/// <summary>
	/// Summary description for Enums.
	/// </summary>
	
	[XmlType(IncludeInSchema = false)]
	public enum LoopType
	{
		[XmlEnum()]
		repeatable,
		[XmlEnum()]
		single
	}

	
}
