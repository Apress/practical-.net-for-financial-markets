using System;

namespace WallStreet.DCE
{
	public class DataInBounder
	{
		private MetaData _metaData;
		private string _fileName;
		private IDecorator _dataConverter ;
		private RowParser _rowParser;
		private ColumnParser _colParser;
		private IBooleanEnumerator _dataEnum;

		public DataInBounder(MetaData metaData,string fileName)
		{
			_metaData = metaData;
			_fileName = fileName;
			_dataConverter = new XMLDecorator();
			
			_dataEnum = new StreamReaderEnumerator(fileName);
			_rowParser = new RowParser(_dataEnum);
			_colParser = new ColumnParser(_dataEnum);

		}

		public void Init()
		{
			foreach ( Band curBand in _metaData.Bands ) 
			{
				CollateBand(curBand,_dataEnum.Next());
			}
		}


		public void CollateBand(Band band,string data)
		{
			BandParser bandParser;

			//Assign the New Band Parser and Data
			bandParser = new BandParser(_dataEnum);
			bandParser.Data = data;
			bandParser.CurrentBand = band;
			_dataConverter.DecorateStartBand(band,bandParser);
			while ( bandParser.Parse()== true ) 
			{
				foreach ( Row row in band.Rows)
				{
					_rowParser = new RowParser(_dataEnum);
					_rowParser.Data = data;
					_rowParser.CurrentRow=row;
					
					if ( row.Band != null ) 
					{
						CollateBand	(row.Band,data);
					}
					else
					{
						CollateRow(row,data);
					}
					
					data = _dataEnum.Next();
				}
				bandParser.Data = data;
			}
			_dataConverter.DecorateEndBand(band);
		}

		public void CollateRow(Row row,string data)
		{

			_dataConverter.DecorateStartRow(row,_rowParser);
			if ( _rowParser.Parse() == false ) 
			{
				_dataConverter.DecorateEndRow(row);
				return ;
			}

			foreach ( Column col in row.Columns)
			{
				CollateCol(row,col,data);
			}
			_dataConverter.DecorateEndRow(row);

		}

		public void CollateCol(Row row,Column col,string data)
		{
			_colParser.CurrentRow = row;
			_colParser.CurrentCol = col;
			_colParser.Data = data;
			_colParser.Parse();
			_dataConverter.DecorateStartColumn(col,_colParser);
			_dataConverter.DecorateEndColumn(col);;			
		}

	}
}
