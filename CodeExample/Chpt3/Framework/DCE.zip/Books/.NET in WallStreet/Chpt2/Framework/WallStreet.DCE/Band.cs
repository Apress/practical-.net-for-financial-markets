using System;
using System.Xml.Serialization;

namespace WallStreet.DCE.Repository
{
	/// <summary>
	/// Summary description for Band.
	/// </summary>
	public class Band : MetaData
	{
		private Row[] _Rows;
		private LoopType _loopMode;

		public Band()
		{
		}

		[XmlAttribute("loop")]
		public LoopType LoopMode
		{
			get{return _loopMode;}
			set{_loopMode=value;}
		}

		[XmlArray("rows")]
		[XmlArrayItem("row",typeof(Row))]
		public Row[] Rows
		{
			get{return _Rows;}
			set{_Rows = value;}
		}
	}
}
