using System;
using WallStreet.DCE.Repository;
using WallStreet.DCE.Translators;

namespace WallStreet.DCE.Collectors
{
	/// <summary>
	/// Summary description for IParser.
	/// </summary>
	public abstract class Parser
	{
		private string _data;
		private IReader _dataReader;
		private MetaData _metaDataInfo;

		public Parser(IReader reader)
		{
			_dataReader = reader;
		}

		public MetaData MetaData
		{
			get{return _metaDataInfo;}
			set{_metaDataInfo = value;}
		}

		public IReader Reader
		{
			get{return _dataReader;}
		}
		
		
		public string Data
		{
			get{return _data;}
			set{_data = value;}
		}

		public abstract bool Parse();
	}
}
