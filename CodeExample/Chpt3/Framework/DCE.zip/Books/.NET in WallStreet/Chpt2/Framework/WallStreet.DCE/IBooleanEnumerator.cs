using System;

namespace WallStreet.DCE
{
	/// <summary>
	/// Summary description for IBooleanEnumerator.
	/// </summary>
	public interface IBooleanEnumerator 
	{
		string Previous();
		string Next();
		
	}
}
