using System;
using WallStreet.DCE.Repository;
using WallStreet.DCE.Translators;

namespace WallStreet.DCE.Collectors
{
	public class ColumnParser : Parser
	{
	#region Variable Declaration
		private string[] _splittedData;
	#endregion
		public ColumnParser(IReader dataReader) :base(dataReader)
		{
		}

		public override bool Parse()
		{
			Row _curRow;

			_curRow = (Row)MetaData.ParentMetaData;
			
			//Check Whether the Delimeter has been Applied
			//At Row Level
			//Logic for Delimeter check is to use the cached array
			if (_curRow.ColDelimeter.Length > 0 )
			{
				if ( this.MetaData.Index == 1 ) 
				{
					_splittedData = Data.Split(_curRow.ColDelimeter.ToCharArray());
				}

				this.Data = _splittedData[this.MetaData.Index - 1];
			}
			else
			{
				//If the current column is a fixed length column
				this.Data = this.Data.Substring(MetaData.Start,MetaData.Length);
			}
			return true;
		}
	}
}
