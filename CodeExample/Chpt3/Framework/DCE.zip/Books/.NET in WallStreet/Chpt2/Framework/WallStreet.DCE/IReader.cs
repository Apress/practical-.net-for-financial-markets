using System;
using System.IO;

namespace WallStreet.DCE.Translators
{
	/// <summary>
	/// Summary description for IBooleanEnumerator.
	/// </summary>
	public interface IReader
	{
		string Previous();
		string Next();
		TextReader BaseReader
		{get;}
	
}
}
