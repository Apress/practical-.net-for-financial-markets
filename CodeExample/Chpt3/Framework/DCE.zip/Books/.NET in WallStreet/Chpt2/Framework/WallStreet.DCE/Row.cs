using System;
using System.Xml.Serialization;

namespace WallStreet.DCE.Repository
{
	/// <summary>
	/// Summary description for Row.
	/// </summary>
	public class Row  : MetaData
	{
		private Column[] _Columns;
		private Band _Band;
		private string _colDelimeter;

		public Row()
		{
		}

		[XmlAttribute("coldelimeter")]
		public string ColDelimeter
		{
			get{return _colDelimeter;}
			set{_colDelimeter=value;}
		}

		[XmlElement("band")]
		public Band Band
		{
			get{return _Band;}
			set{_Band = value;}
		}

		[XmlArray("cols")]
		[XmlArrayItem("col",typeof(Column))]
		public Column[] Columns
		{
			get{return _Columns;}
			set{_Columns = value;}
		}

	}
}
