using System;
using System.IO;
using WallStreet.DCE.Repository;
using WallStreet.DCE.Translators;

namespace WallStreet.DCE.Collectors
{
	/// <summary>
	/// Summary description for BandParser.
	/// </summary>
	public class BandParser : Parser
	{
		private int _iterationCount = 0;


		public BandParser(IReader dataReader) :base(dataReader)
		{
		}


		public override bool Parse()
		{
			Band curBand = (Band)MetaData;

			if ( Data == null ) 
			{
				return false;
			}

			if ( curBand.LoopMode == LoopType.single )
			{
				if ( _iterationCount >= 1 ) 
				{
					_iterationCount  = 0 ;
					Reader.Previous();
					return false;
				}
				else
				{
					_iterationCount++;
					return true;
				}
			}

			if ( curBand.LoopMode == LoopType.repeatable)
			{
				if ( Data.Substring(curBand.Start,curBand.Identifier.Length) == curBand.Identifier )
				{
					return true;
				}
				Reader.Previous();
			}
			_iterationCount = 0 ;
			return false;
		}
		}
}
