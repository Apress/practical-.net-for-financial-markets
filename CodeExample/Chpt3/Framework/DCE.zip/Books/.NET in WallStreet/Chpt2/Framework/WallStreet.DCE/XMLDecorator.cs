using System;
using System.Xml;

namespace WallStreet.DCE
{
	/// <summary>
	/// Summary description for XMLConverter.
	/// </summary>
	public class XMLDecorator: IDecorator
	{
		private XmlTextWriter _xmlWriter;

		public XMLDecorator()
		{
			_xmlWriter = new XmlTextWriter(Console.Out);
			_xmlWriter.Formatting=  Formatting.Indented;
			_xmlWriter.Indentation = 4;
		}

		#region IDecorator Members

		public void DecorateEndColumn(MetaDataInfo metaDataInfo)
		{
			_xmlWriter.WriteEndAttribute();
		}

		public void DecorateEndBand(MetaDataInfo metaDataInfo)
		{
			_xmlWriter.WriteEndElement();
		}

		public void DecorateEndRow(MetaDataInfo metaDataInfo)
		{
			_xmlWriter.WriteEndElement();
		}

		public void DecorateStartColumn(MetaDataInfo metaDataInfo, Parser parser)
		{
			_xmlWriter.WriteStartAttribute(metaDataInfo.Name,"");
			_xmlWriter.WriteString(parser.Data);				

		}

		public void DecorateStartRow(MetaDataInfo metaDataInfo, Parser parser)
		{
			_xmlWriter.WriteStartElement(metaDataInfo.Name);
		}

		public void DecorateStartBand(MetaDataInfo metaDataInfo, Parser parser)
		{
			_xmlWriter.WriteStartElement(metaDataInfo.Name);
		}

		#endregion
	}
}
