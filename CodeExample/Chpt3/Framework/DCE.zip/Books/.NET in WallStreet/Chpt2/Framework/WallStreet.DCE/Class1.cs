using System;
using System.IO;
using System.Xml.Serialization;
using WallStreet.DCE.Repository;
using WallStreet.DCE.Collectors;
using WallStreet.DCE.Translators;

namespace WallStreet.DCE
{
	class Class1
	{
		[STAThread]
		static void Main(string[] args)
		{
			StreamDataReader dataRdr = new StreamDataReader(new StreamReader(@"C:\test2.txt"));
			XMLDataWriter dataWrt= new XMLDataWriter(new StringWriter());
			DataConverter _dataConverter= new DataConverter(@"C:\Books\.NET in WallStreet\Chpt2\Framework\WallStreet.DCE\MTM535.xml",dataRdr,dataWrt);
			_dataConverter.Convert();
			Console.WriteLine(dataWrt.BaseWriter.ToString());
			Console.ReadLine();
		}
	}
}
